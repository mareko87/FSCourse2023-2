import "./App.css";
import Lista from "./components/Lista";
import Naslov from "./components/Naslov";

const App = () => {
  return (
    <div className="App">
      <Naslov />
      <Lista />
    </div>
  );
};

export default App;
