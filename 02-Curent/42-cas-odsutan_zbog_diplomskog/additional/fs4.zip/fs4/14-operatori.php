<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <h1>Operatori</h1>
    <ul>
        <li>aritmeticki</li>
        <li>operatori dodele</li>
        <li>operatori poredjenja</li>
        <li>logicki operatori</li>
    </ul>
</body>
</html>