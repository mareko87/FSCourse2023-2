import { useState } from "react";
import { increment, decrement } from "../actions";
import { useSelector, useDispatch } from "react-redux";

const Proizvodi = () => {
  const broj = useSelector((state) => state.broj);
  const items = useSelector((state) => state.items);

  const dispatch = useDispatch();

  const [naziv, setNaziv] = useState("");
  const [cena, setCena] = useState(0);

  //   const [broj, setBroj] = useState(42);
  //   const [items, setItems] = useState([
  //     {
  //       id: 1,
  //       naziv: "hleb",
  //       cena: 100,
  //     },
  //     {
  //       id: 2,
  //       naziv: "mleko",
  //       cena: 150,
  //     },
  //     {
  //       id: 3,
  //       naziv: "jogurt",
  //       cena: 200,
  //     },
  //   ]);

  return (
    <div>
      <h4>
        <button
          className="btn btn-primary"
          onClick={() => dispatch(decrement())}
        >
          -
        </button>
        {broj}
        <button
          className="btn btn-primary"
          onClick={() => dispatch(increment())}
        >
          +
        </button>
      </h4>

      <hr />
      <input
        type="text"
        placeholder="naziv"
        value={naziv}
        onChange={(event) => setNaziv(event.target.value)}
      />
      <input
        type="number"
        placeholder="cena"
        value={cena}
        onChange={(event) => setCena(event.target.value)}
      />
      <button
        className="btn btn-primary"
        onClick={() =>
          dispatch({
            type: "ADD",
            payload: { id: items.length + 1, naziv: naziv, cena: cena },
          })
        }
      >
        Dodaj
      </button>
      <hr />
      <ul>
        {items.map(({ id, naziv, cena }) => {
          return (
            <li key={id}>
              id: {id} naziv: {naziv} cena: {cena}
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Proizvodi;
