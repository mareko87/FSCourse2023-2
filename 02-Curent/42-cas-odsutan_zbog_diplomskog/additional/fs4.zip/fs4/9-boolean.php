<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <h1>Boolean - logicke vrednosti</h1>
    <?php 
    $istina = true;
    $laz = false;
    echo "Tip promenljive: " . gettype($istina);
    echo "<hr>";
    echo "Tip promenljive: " . gettype($laz);
    ?>
</body>
</html>