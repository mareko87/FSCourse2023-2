import { useState } from "react";

const Forma = () => {
  const [osoba, setOsoba] = useState({
    ime: "",
    prezime: "",
    datRodj: "",
  });

  const formaSubmitovana = (event) => {
    event.preventDefault();

    // console.log(event.target.ime); // polje
    // console.log(event.target.ime.value); // vrednost iz input-a

    setOsoba({
      ime: event.target.ime.value,
      prezime: event.target.prezime.value,
      datRodj: event.target.datRodj.value,
    });
  };

  return (
    <>
      <form onSubmit={formaSubmitovana}>
        <label>
          Ime: <input type="text" name="ime" />
        </label>{" "}
        <br />
        <label>
          Prezime: <input type="text" name="prezime" />
        </label>{" "}
        <br />
        <label>
          Datum rodjenja: <input type="text" name="datRodj" />
        </label>{" "}
        <br />
        <input type="submit" value="Submit" />
      </form>

      <hr />

      <h3>Ime: {osoba.ime}</h3>
      <h3>Prezime: {osoba.prezime}</h3>
      <h3>Datum rodjenja: {osoba.datRodj}</h3>
    </>
  );
};

export default Forma;
