const sabiranje = (a, b) => {
  console.log("dodali na github-u");
  console.log(a);
  return a + b;
};
