import React from "react";

const Komp1 = (props) => {
  return (
    <div>
      <h4>Komp1</h4>
      {/* <button
        onClick={() =>
          props.promeniTekst("Neki novi tekst iz children komponente")
        }
      >
        Promena teksta
      </button> */}
      <button onClick={() => props.setNaziv("Websitesworkshop")}>
        Promena stanja - naziv
      </button>
    </div>
  );
};

export default Komp1;
