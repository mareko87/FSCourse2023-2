import { useState } from "react";

const Automobil = () => {
  const [vozilo, setVozilo] = useState({ marka: "Skoda", tip: "Superb" });

  const promeniStanje = () => {
    setVozilo({ marka: "Toyota", tip: "Yaris" });
  };

  return (
    <div>
      <h1>Automobil</h1>
      <h3>
        Marka: {vozilo.marka} Tip: {vozilo.tip}{" "}
      </h3>
      <button onClick={promeniStanje}>Promeni stanje</button>
      <hr />
    </div>
  );
};

export default Automobil;
