// const osoba = {
//   ime: "Petar",
//   prezime: "Petrovic",
//   godine: 44,
// };

// const fun = (osoba) => {
//   console.log(osoba.ime);
//   console.log(osoba.prezime);
//   console.log(osoba.godine);
// };

// const fun = ({ ime, prezime, godine }) => {
//   console.log(ime);
//   console.log(prezime);
//   console.log(godine);
// };

// fun(osoba);

// let [a, b] = [1, 2, 3, 4];

// console.log(a);
// console.log(b);

// let { ime, prezime } = { ime: "Petar", prezime: "Petrovic", godine: 44 };

// console.log(`${ime} ${prezime}`);

// Uvoz i izvoz iz funkcija/fajlova - koriscenjem require

// const fun1 = require("./fun1");
// console.log(fun1);

// console.log(fun1.sabiraj(2, 3));
// console.log(fun1.osoba);

// sa object destructuring

// const { sabiraj, osoba } = require("./fun1");

// console.log(sabiraj(4, 4));
// console.log(osoba);

// Uvoz i izvoz iz funkcija/fajlova - import
// import fun2 from "./fun2.mjs"; //izveze samo oduzimaj, kada pise export default oduzimaj

import { oduzimaj, auto } from "./fun2.mjs";

console.log(oduzimaj(5, 2));
