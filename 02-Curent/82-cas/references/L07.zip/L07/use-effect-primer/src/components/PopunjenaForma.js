import { useEffect, useState } from "react";

const PopunjenaForma = ({ prime }) => {
  const [ime, setIme] = useState("");
  const [prezime, setPrezime] = useState("");

  useEffect(() => {
    setIme(prime.ime);
    setPrezime(prime.prezime);
  }, []);

  return (
    <div>
      <h3>PopunjenaForma</h3>

      <form>
        <label>Ime:</label>
        <input
          type="text"
          value={ime}
          onChange={(event) => setIme(event.target.value)}
        />
        <label>Prezime:</label>
        <input
          type="text"
          value={prezime}
          onChange={(event) => setPrezime(event.target.value)}
        />
      </form>
    </div>
  );
};

export default PopunjenaForma;
