import "./App.css";
// import Forma from "./components/Forma";
// import Forma2 from "./components/Forma2";
import Forma3 from "./components/Forma3";

const App = () => {
  return (
    <>
      {/* <Forma /> */}
      {/* <Forma2 /> */}
      <Forma3 />
    </>
  );
};

export default App;
