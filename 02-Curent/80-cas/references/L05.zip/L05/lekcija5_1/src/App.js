import "./App.css";
import Navbar from "./components/Navbar";
import PodeljenaRavan from "./components/PodeljenaRavan";
import Kontakti from "./components/Kontakti";
import Chat from "./components/Chat";

const App = () => {
  let naziv = "Websitesworkshop";

  return (
    <div className="App">
      <Navbar />
      <PodeljenaRavan
        levaKomponenta={<Kontakti naziv={naziv}></Kontakti>}
        desnaKomponenta={<Chat />}
      ></PodeljenaRavan>
    </div>
  );
};

export default App;
