import { useEffect, useState, useMemo } from "react";

import "./App.css";

const App = () => {
  const [universities, setUniversities] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    // fetch("http://universities.hipolabs.com/search?country=United+States")
    //   .then((res) => res.json())
    //   .then((unis) => {
    //     setUniversities([...unis]);
    //     console.log(unis);
    //   });

    // nacin as async
    // (async () => {
    //   fetch("http://universities.hipolabs.com/search?country=United+States")
    //     .then((res) => res.json())
    //     .then((unis) => {
    //       setUniversities([...unis]);
    //       console.log(unis);
    //     });
    // })();

    // nacin sa async/await

    (async () => {
      setLoading(true);

      const res = await fetch(
        "http://universities.hipolabs.com/search?country=United+States"
      );

      const unis = await res.json();

      setUniversities([...unis]);
      // console.log(unis);

      setLoading(false);
    })();
  }, []);

  // const rezPretrage = universities.filter((uni, idx) => {
  //   if (uni.name.toUpperCase().includes(searchTerm.toUpperCase())) {
  //     console.log(uni);
  //     return uni; // vracamo univerzitet koji sadrzi taj searchTerm koji smo upisali u input polje
  //   }
  // });

  const rezPretrage = useMemo(() => {
    return universities.filter((uni, idx) => {
      if (uni.name.toUpperCase().includes(searchTerm.toUpperCase())) {
        console.log(uni.name);
        return uni; // vracamo univerzitet koji sadrzi taj searchTerm koji smo upisali u input polje
      }
    });
  }, [searchTerm, universities]);

  return (
    <div className="App">
      <input
        type="text"
        value={searchTerm}
        onChange={(event) => setSearchTerm(event.target.value)}
      />
      <hr />
      {loading ? (
        <h3>Loading...</h3>
      ) : (
        <ul>
          {/* {universities.map((uni, idx) => {
            return <li key={idx}>{uni.name}</li>;
          })} */}
          {rezPretrage.map((uni, idx) => {
            return <li key={idx}>{uni.name}</li>;
          })}
        </ul>
      )}
    </div>
  );
};

export default App;
