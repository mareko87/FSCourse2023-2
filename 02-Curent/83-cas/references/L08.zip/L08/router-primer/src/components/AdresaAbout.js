import React from "react";

const AdresaAbout = () => {
  return <div>AdresaAbout</div>;
};

export default AdresaAbout;
