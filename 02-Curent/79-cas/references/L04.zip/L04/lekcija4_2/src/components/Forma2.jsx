import { useState } from "react";

const Forma2 = () => {
  //   const [ime, setIme] = useState("");
  //   const [prezime, setPrezime] = useState("");
  //   const [datRodj, setDatRodj] = useState("");

  const [osoba, setOsoba] = useState({
    ime: "",
    prezime: "",
    datRodj: "",
  });

  //   const imeOnChangeHandler = (event) => {
  //     setIme(event.target.value);
  //   };

  const imeOnChangeHandler = (event) => {
    setOsoba({
      ime: event.target.value,
      prezime: osoba.prezime,
      datRodj: osoba.datRodj,
    });
  };

  const prezimeOnChangeHandler = (event) => {
    setOsoba({
      ime: osoba.ime,
      prezime: event.target.value,
      datRodj: osoba.datRodj,
    });
  };

  const datRodjOnChangeHandler = (event) => {
    setOsoba({
      ime: osoba.ime,
      prezime: osoba.prezime,
      datRodj: event.target.value,
    });
  };

  return (
    <>
      {/* <form>
        <label>
          {/* Ime: <input type="text" onChange={imeOnChangeHandler} /> */}
      {/* Ime:
          <input
            type="text"
            value={ime}
            onChange={(event) => {
              setIme(event.target.value);
            }}
          /> */}
      {/* </label>
        <br />
        <label>
          Prezime:{" "}
          <input
            type="text"
            value={prezime}
            onChange={(event) => setPrezime(event.target.value)}
          />
        </label>{" "}
        <br />
        <label>
          Datum rodjenja:{" "}
          <input
            type="text"
            value={datRodj}
            onChange={(event) => setDatRodj(event.target.value)}
          />
        </label>{" "}
        <br />
        {/* <input type="submit" value="Submit" /> */}
      {/* </form> */}

      {/* <button onClick={() => console.log(ime, prezime, datRodj)}>
        Submit van forme
      </button> */}

      <form>
        <label>
          Ime: <input type="text" onChange={imeOnChangeHandler} />
        </label>
        <br />
        <label>
          Prezime: <input type="text" onChange={prezimeOnChangeHandler} />
        </label>
        <br />
        <label>
          Datum rodjenja:{" "}
          <input type="text" onChange={datRodjOnChangeHandler} />
        </label>
        <br />
        <input type="submit" value="Submit" />
      </form>

      {/* <h3>Ime: {ime}</h3>
      <h3>Prezime: {prezime}</h3>
      <h3>Datum rodjenja: {datRodj}</h3> */}

      <h3>Ime: {osoba.ime}</h3>
      <h3>Prezime: {osoba.prezime}</h3>
      <h3>Datum rodjenja: {osoba.datRodj}</h3>
    </>
  );
};

export default Forma2;
