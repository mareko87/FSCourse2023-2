import { useState } from "react";
import "./App.css";
import Forma from "./components/Forma/Forma";
import Lista from "./components/Lista/Lista";

const App = () => {
  const [teniseri, setTeniseri] = useState([
    {
      teniser: "Novak Djokovic",
      drzava: "Srbija",
      god: 36,
    },
    {
      teniser: "Rafael Nadal",
      drzava: "Spanija",
      god: 37,
    },
    {
      teniser: "Roger Federer",
      drzava: "Svajcarska",
      god: 42,
    },
  ]);

  return (
    <div className="App">
      {/* <Forma teniseri={teniseri} setTeniseri={setTeniseri} /> */}
      <Forma setTeniseri={setTeniseri} />
      <Lista teniseri={teniseri} setTeniseri={setTeniseri} />
    </div>
  );
};

export default App;
