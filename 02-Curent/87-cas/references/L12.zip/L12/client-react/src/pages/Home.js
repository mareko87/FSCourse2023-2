import React from "react";

const Home = () => {
  return (
    <div>
      <header>
        <article>
          <h1>Online outdoor shop, buy online outdoor clothing & trekking</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates
            magnam, earum a dignissimos libero, illum quo, reprehenderit nostrum
            amet assumenda culpa provident tempore impedit ab et qui excepturi
            fugiat sunt.
          </p>
          <button>Order now</button>
        </article>
      </header>

      <section className="featuredItems container">
        <h2>Featured Items</h2>
        <div className="owl-carousel owl-theme">
          <div className="item">
            <a href="single.html">
              <img src="img/boots.jpg" alt="" />
              <h3>Boots</h3>
              <p>$210.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/pants.jpg" alt="" />
              <h3>Pants</h3>
              <p>$40.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/poles.jpg" alt="" />
              <h3>Poles</h3>
              <p>$40.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/jackets.jpg" alt="" />
              <h3>Jackets</h3>
              <p>$70.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/skirts.jpg" alt="" />
              <h3>Skirts</h3>
              <p>$60.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/shirts.jpg" alt="" />
              <h3>Shirts</h3>
              <p>$40.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/socks.jpg" alt="" />
              <h3>Socks</h3>
              <p>$10.00</p>
            </a>
          </div>
          <div className="item">
            <a href="single.html">
              <img src="img/gloves.jpg" alt="" />
              <h3>Gloves</h3>
              <p>$25.00</p>
            </a>
          </div>
        </div>
      </section>

      <section className="subscribe">
        <article className="container">
          <h3>Subscribe on Hiking shop now!</h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br />{" "}
            Amet vitae atque harum minima sint accusantium optio, laborum
            necessitatibus rem laudantium!
          </p>
          <form>
            <input type="text" placeholder="Your email..." />
            <input type="submit" value="Subscribe" />
          </form>
        </article>
      </section>
    </div>
  );
};

export default Home;
