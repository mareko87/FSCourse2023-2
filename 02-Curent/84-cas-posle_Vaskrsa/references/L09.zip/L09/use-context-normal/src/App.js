import "./App.css";
import Korpa from "./components/Korpa";
import Navbar from "./components/Navbar";
import Proizvodi from "./components/Proizvodi";
import { BrojProvider } from "./context/BrojContext";
import { ProizvodiProvider } from "./context/ProizvodiContext";

const App = () => {
  return (
    <div className="App">
      <ProizvodiProvider>
        <BrojProvider>
          <Navbar />
          <Proizvodi />
          <Korpa />
        </BrojProvider>
      </ProizvodiProvider>
    </div>
  );
};

export default App;
