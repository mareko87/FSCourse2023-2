// import React from 'react'

const Navbar = () => {
  return <div>Ovo je navigaciona traka</div>;
};

export default Navbar;
