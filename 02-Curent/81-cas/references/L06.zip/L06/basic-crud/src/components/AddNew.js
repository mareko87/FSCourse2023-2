import { useState } from "react";
import { v4 as uuidv4 } from "uuid";

const AddNew = ({ osobe, setOsobe }) => {
  const [ime, setIme] = useState("");
  const [prezime, setPrezime] = useState("");
  const [god, setGod] = useState("");

  const formSubmit = (event) => {
    event.preventDefault();

    // const tempOsoba = {
    //   id: uuidv4(),
    //   ime,
    //   prezime,
    //   god,
    // };

    // setOsobe([...osobe, tempOsoba]);

    setOsobe((prevState) => [
      ...prevState,
      { id: uuidv4(), ime, prezime, god },
    ]);

    setIme("");
    setPrezime("");
    setGod("");

    event.target.ime.focus(); //stari, js nacin
  };

  return (
    <div style={{ marginBottom: "20px" }}>
      <h2>AddNew</h2>
      <form onSubmit={formSubmit}>
        <label>Ime</label>
        <input
          type="text"
          value={ime}
          name="ime"
          onChange={(event) => setIme(event.target.value)}
        />
        <label>Prezime</label>
        <input
          type="text"
          value={prezime}
          onChange={(event) => setPrezime(event.target.value)}
        />
        <label>Godine</label>
        <input
          type="text"
          value={god}
          onChange={(event) => setGod(event.target.value)}
        />
        <input style={{ marginLeft: "5px" }} type="submit" value="Dodaj" />
      </form>
    </div>
  );
};

export default AddNew;
