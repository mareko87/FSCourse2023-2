import { useState } from "react";
import stilovi from "./Forma.module.css";

const Forma = ({ setTeniseri }) => {
  const [teniser, setTeniser] = useState("");
  const [drzava, setDrzava] = useState("");
  const [god, setGod] = useState(""); // kada se nesto cita iz forme, uvek dobijamo string

  const formSubmitted = (event) => {
    event.preventDefault();

    let noviTeniser = {
      teniser,
      drzava,
      god,
    };

    // setTeniseri([...teniseri, noviTeniser]);

    // setTeniseri((prethodnaVrednost) => {
    //   let novoStanje = [...prethodnaVrednost, noviTeniser];
    //   return novoStanje;
    // });

    // setTeniseri((prethodnaVrednost) => {
    //   return [...prethodnaVrednost, noviTeniser];
    // });

    if (teniser !== "" && drzava !== "" && god !== "") {
      setTeniseri((prethodnaVrednost) => [...prethodnaVrednost, noviTeniser]);

      setTeniser("");
      setDrzava("");
      setGod("");
    }
  };

  return (
    <div>
      {/* <h4>Forma</h4> */}
      <form onSubmit={formSubmitted} className={stilovi.forma}>
        <label>Teniser:</label>
        <input
          type="text"
          value={teniser}
          onChange={(e) => setTeniser(e.target.value)}
        />
        <label>Drzava:</label>
        <input
          type="text"
          value={drzava}
          onChange={(e) => setDrzava(e.target.value)}
        />
        <label>Godine:</label>
        <input
          type="text"
          value={god}
          onChange={(e) => setGod(e.target.value)}
        />
        <input className={stilovi.dugme} type="submit" value="Dodaj" />
      </form>
    </div>
  );
};

export default Forma;
