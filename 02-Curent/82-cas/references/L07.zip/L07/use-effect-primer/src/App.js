import { useState, useEffect } from "react";
import "./App.css";
import PrimerFetch from "./components/PrimerFetch";
import PopunjenaForma from "./components/PopunjenaForma";

const App = () => {
  // useEffect sluzi za rad sa sporednim efektima - fetch-ovanje podataka (asinhrono dohvatanje podataka)

  const [brojac, setBrojac] = useState(0);
  const [brojac2, setBrojac2] = useState(0);

  const [prime, setPrime] = useState({
    ime: "Petar",
    prezime: "Petrovic",
  });

  // 1) Ova funkcija se izvrsava prilikom svakog rendera komponente
  // useEffect(() => {
  //   console.log("renderovano");
  // });

  // 2) Ova funkcija se izvrsava samo jednom, prilikom inicijalnog rendera komponente - kao onload
  // Koristi se kada je nesto potrebno izvrsiti samo prvi put kada se komponenta renderuje
  // useEffect(() => {
  //   console.log("renderovano");
  // }, []);

  // 3) - Ova funkcija se izvrsava samo jednom prilikom inicijalnog rendera komponente - kao onload
  //  - izvrsava se prilikom renderinga komponente kada postoji promena na stanju koje je navedeno kao zavisnost (nalazi se u dependency array-u)
  useEffect(() => {
    console.log("renderovano");
  }, [brojac]);

  useEffect(() => {
    console.log("renderovano2");
  }, [brojac2]);

  return (
    <div className="App">
      <h1>Naslov</h1>
      <button onClick={() => setBrojac((prev) => prev + 1)}>
        Renderovanje
      </button>

      {brojac}

      <button onClick={() => setBrojac2((prev) => prev + 1)}>
        Renderovanje 2
      </button>
      {brojac2}

      <hr />

      <PrimerFetch brojac={brojac} />
      <PopunjenaForma prime={prime} />
    </div>
  );
};

export default App;
