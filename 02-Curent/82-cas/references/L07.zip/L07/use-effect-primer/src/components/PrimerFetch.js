import { useEffect, useState } from "react";

const PrimerFetch = ({ brojac }) => {
  const [kucici, setKucici] = useState([]);

  useEffect(() => {
    fetch("https://dog.ceo/api/breeds/image/random")
      .then((res) => res.json())
      .then((json) => {
        console.log(json);
        setKucici((prev) => [...prev, json.message]);
      })
      .then((_) => {
        console.log(kucici);
      });
  }, [brojac]);

  return (
    <div>
      <h3>PrimerFetch</h3>

      {kucici.map((kuce, idx) => {
        return <img key={idx} src={kuce} height="200px" />;
      })}
    </div>
  );
};

export default PrimerFetch;
