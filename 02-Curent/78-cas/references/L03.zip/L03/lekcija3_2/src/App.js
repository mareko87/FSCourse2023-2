import Kartica from "./components/Kartica";
import "./App.css";

const App = () => {
  const automobili = [
    {
      id: 1,
      marka: "Audi",
      tip: "A6",
      god: 2007,
    },
    {
      id: 2,
      marka: "Reno",
      tip: "Clio",
      god: 2018,
    },
    {
      id: 3,
      marka: "Yugo",
      tip: "Florida 90",
      god: 2000,
    },
    {
      id: 4,
      marka: "pezo",
      tip: "307",
      god: 2000,
    },
  ];
  return (
    <div className="App">
      <Kartica automobili={automobili} />
    </div>
  );
};

export default App;
