import { useState } from "react";

const Forma3 = () => {
  const [ime, setIme] = useState("");
  const [prezime, setPrezime] = useState("");
  const [datRodj, setDatRodj] = useState("");

  const [osobe, setOsobe] = useState([
    {
      ime: "Milan",
      prezime: "Milanovic",
      datRodj: "22",
    },
    {
      ime: "Ivana",
      prezime: "Ivanovic",
      datRodj: "32",
    },
  ]);

  const submitOsoba = (event) => {
    event.preventDefault();

    setOsobe([{ ime: ime, prezime: prezime, datRodj: datRodj }]);

    const novaOsoba = {
      ime: ime,
      prezime: prezime,
      datRodj: datRodj,
    };

    setOsobe([...osobe, novaOsoba]);
  };

  const brisanje = (idx) => {
    console.log(idx);

    let tempOsobe = [...osobe];

    tempOsobe.splice(idx, 1);

    setOsobe(tempOsobe);
  };
  return (
    <>
      <form onSubmit={submitOsoba}>
        <label>
          Ime:{" "}
          <input
            type="text"
            value={ime}
            onChange={(e) => setIme(e.target.value)}
          />
        </label>
        <br />
        <label>
          Prezime:{" "}
          <input
            type="text"
            value={prezime}
            onChange={(e) => setPrezime(e.target.value)}
          />
        </label>
        <br />
        <label>
          Datum rodjenja:{" "}
          <input
            type="text"
            value={datRodj}
            onChange={(e) => setDatRodj(e.target.value)}
          />
        </label>
        <br />
        <input type="submit" value="Submit" />
      </form>

      <hr />
      <h3>Ime: {ime}</h3>
      <h3>Prezime: {prezime}</h3>
      <h3>Datum rodjenja: {datRodj}</h3>

      <hr />

      {osobe.map((osoba, idx) => {
        return (
          <div key={idx}>
            <h3>Ime: {osoba.ime}</h3>
            <h3>Prezime: {osoba.prezime}</h3>
            <h3>Datum rodjenja: {osoba.datRodj}</h3>
            <button onClick={() => brisanje(idx)}>Obrisi</button>
          </div>
        );
      })}
    </>
  );
};

export default Forma3;
