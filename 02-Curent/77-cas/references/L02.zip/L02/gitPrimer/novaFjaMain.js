const funkcija2 = () => {
  console.log("proba 123");

  //   neki komentar

  let ime = "pera";

  return <div>nova funkcija {ime}</div>;
};
