const proba = (a, b, c) => {
  if (a > b) {
    return 1;
  } else if (a < b) {
    return -1;
  }
  return c;
};

export default proba;
