import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState } from "react";

import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import About from "./pages/About";
import Dashboard from "./pages/Dashboard";
import Details from "./pages/Details";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";

import "./App.css";
import MapaAbout from "./components/MapaAbout";
import AdresaAbout from "./components/AdresaAbout";

const App = () => {
  const [osobe, setOsobe] = useState([
    {
      id: 1,
      prime: "Petar Petrovic",
      godrod: 1992,
    },
    {
      id: 2,
      prime: "Marija Markovic",
      godrod: 1968,
    },
    {
      id: 3,
      prime: "Visnja Visnjic",
      godrod: 1995,
    },
  ]);

  return (
    <div className="App">
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard osobe={osobe} />} />

          {/* <Route path="/details" element={<Details />} /> */}

          {/* <Route path="/details" element={<Details osobe={osobe} />}>
            <Route path=":id" element={<Details />} />
          </Route> */}

          <Route path="/details/:id" element={<Details osobe={osobe} />} />

          {/* <Route path="/about" element={<About />} /> */}

          <Route path="/about" element={<About />}>
            <Route path="mapa" element={<MapaAbout />} />
            <Route path="adresa" element={<AdresaAbout />} />
          </Route>

          <Route path="/*" element={<NotFound />} />
        </Routes>

        <Footer />
      </BrowserRouter>
    </div>
  );
};

export default App;
