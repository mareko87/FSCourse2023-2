import React from "react";
import stilovi from "./Lista.module.css";

const Lista = ({ teniseri, setTeniseri }) => {
  const obrisiTenisera = (idx) => {
    // 1. nacin sa prethodnog casa
    // let tempStanje = [...teniseri];
    // tempStanje.splice(idx, 1);

    // setTeniseri(tempStanje);

    // 2.nacin

    setTeniseri((prevState) => {
      let tempState = [...prevState];
      tempState.splice(idx, 1);
      return tempState;
    });
  };
  return (
    <div className={stilovi.lista}>
      {/* <h4>Lista</h4> */}

      <ul>
        {teniseri.map((teniser, idx) => {
          return (
            <li key={idx} className={stilovi.element}>
              {idx + 1}. {teniser.teniser} {teniser.drzava} {teniser.god}
              <button
                onClick={() => obrisiTenisera(idx)}
                className={stilovi.dugme}
              >
                Obrisi
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Lista;
