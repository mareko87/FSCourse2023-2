import { createContext, useEffect, useState } from "react";

const ProizvodiContext = createContext();

export const ProizvodiProvider = ({ children }) => {
  //   const [proizvodi, setProizvodi] = useState([
  //     {
  //       id: 1,
  //       naziv: "hleb",
  //       cena: 55,
  //     },
  //     {
  //       id: 2,
  //       naziv: "mleko",
  //       cena: 140,
  //     },
  //     {
  //       id: 3,
  //       naziv: "jogurt",
  //       cena: 230,
  //     },
  //   ]);

  const [proizvodi, setProizvodi] = useState([]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((json) => {
        console.log(json);
        setProizvodi(json);
      });
  }, []);

  return (
    <ProizvodiContext.Provider value={{ proizvodi, setProizvodi }}>
      {children}
    </ProizvodiContext.Provider>
  );
};

export default ProizvodiContext;
