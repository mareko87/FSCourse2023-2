let korpa = [];

window.addEventListener('load', () => {
    if (sessionStorage.getItem('korpa')) {
        korpa = JSON.parse(sessionStorage.getItem('korpa'));
        document.querySelector('#brStavki').innerHTML = `(${korpa.length})`
    }
})