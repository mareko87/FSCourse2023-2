console.log('Pozrav iz eksternog JS fajla');

console.log('Prvi log iz HMTL dokumenta');

console.error("Imate gresku u JS!");

console.log("Da l' ste bili kod nas? ");
console.log('Da l\' ste bili kod nas? ');

console.log('Marko je rekao :"Danas je lep dan."');
console.log("Marko je rekao :\"Danas je lep dam.\"");

let a = 3;
let b = 5;

let c = a + b;

console.log('Rezultat je ' + c); //- konkatenacija - concatenation
console.log('Rezultat ' + a + '+' + b + '=' + c);