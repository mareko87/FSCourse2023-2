import { useState } from "react";
import "./App.css";
import Komp1 from "./Komp1";

const App = () => {
  let tekst = "neki tekst"; // promenljiva koja nije stanje

  const [naziv, setNaziv] = useState("Skola programiranja");

  console.log(tekst);

  const promeniTekst = (noviTekst) => {
    tekst = noviTekst;
    console.log(tekst);
  };

  // promeniTekst("proba123");
  return (
    <div className="App">
      <Komp1 promeniTekst={promeniTekst} setNaziv={setNaziv} />
      {/* {tekst} */}
      {naziv}
    </div>
  );
};

export default App;
