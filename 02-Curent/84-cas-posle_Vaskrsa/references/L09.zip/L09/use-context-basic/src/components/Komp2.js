import { useContext } from "react";
import { BrojContext } from "../App";

const Komp2 = () => {
  const { broj } = useContext(BrojContext);
  return <div>Komp2 - {broj}</div>;
};

export default Komp2;
