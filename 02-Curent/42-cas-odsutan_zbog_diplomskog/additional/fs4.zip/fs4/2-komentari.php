<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <h1>Komentari</h1>
    <ul>
        <li>Linijski - jednoredni</li>
        <li>Blok komentar - viseredni</li>
    </ul>
    <?php 
    // linijski 
    echo 'jednolinijski ili jednoredni komentar'
    /*
    sanele ti odradi formu
    vukasine ti odradi header
    arnolde tvoj je footer
    */
    // echo '<br>';
    // echo 'ovu i prehtodnu liniju cemo da sakrijemo';
    ?>
</body>
</html>