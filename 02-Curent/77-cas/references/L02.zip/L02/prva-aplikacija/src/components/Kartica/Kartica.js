import "./Kartica.css";

const Kartica = (props) => {
  console.log("props", props);
  return (
    <div className="kartica">
      <h1>Dobrodosli na kurs react-a!</h1>

      {/* <h2>POhadjam kurs u {props.promenljivaIzApp}</h2> */}

      <h2>id: {props.osoba.id}</h2>
      <h3>ime: {props.osoba.ime}</h3>
      <h4>godine: {props.osoba.godine}</h4>
    </div>
  );
};

export default Kartica;
