import "./Komp1.css";

const Komp1 = () => {
  return (
    <div>
      <h1 className="komp1-h1">Pozdrav iz Komponente 1</h1>
    </div>
  );
};

export default Komp1;
