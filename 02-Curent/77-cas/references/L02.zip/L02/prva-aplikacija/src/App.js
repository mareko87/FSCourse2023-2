/* eslint-disable no-unused-vars */
import Kartica from "./components/Kartica/Kartica";
import Navbar from "./components/Navbar/Navbar";
import Footer from "./components/Footer/Footer";

const App = () => {
  let naziv = "Websitesworkshop";

  const osobe = [
    {
      id: 1,
      ime: "Petar",
      godine: 54,
    },
    {
      id: 2,
      ime: "Marija",
      godine: 23,
    },
    {
      id: 3,
      ime: "Jovana",
      godine: 28,
    },
  ];

  return (
    <div>
      {/* <Kartica promenljivaIzApp={naziv} osobe={osobe} /> */}

      <Navbar />

      {/* <Kartica osoba={osobe[0]} />
      <Kartica osoba={osobe[1]} />
      <Kartica osoba={osobe[2]} /> */}

      {osobe.map((osoba) => {
        return <Kartica osoba={osoba} />;
      })}

      <Footer />

      {/* <h1>Proba da li radi</h1>
      <h2>naziv je {naziv}</h2>

      <br />

      <h2>id: {osobe[0].id}</h2>
      <h3>ime: {osobe[0].ime}</h3>
      <h4>godine: {osobe[0].godine}</h4>
      <hr />

      <h2>id: {osobe[1].id}</h2>
      <h3>ime: {osobe[1].ime}</h3>
      <h4>godine: {osobe[1].godine}</h4>
      <hr />

      <h2>id: {osobe[2].id}</h2>
      <h3>ime: {osobe[2].ime}</h3>
      <h4>godine: {osobe[2].godine}</h4>
      <hr /> */}
    </div>
  );
};

export default App;
