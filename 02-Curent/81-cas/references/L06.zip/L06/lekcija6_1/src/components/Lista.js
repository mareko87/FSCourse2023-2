import React, { useState } from "react";
import Prikaz from "./Prikaz";

const Lista = () => {
  const [zivotinje, setZivotinje] = useState([
    // {
    //   id: 1,
    //   ime: "Spajk",
    //   tip: "pas",
    //   god: 4,
    // },
    // {
    //   id: 2,
    //   ime: "Tom",
    //   tip: "macka",
    //   god: 3,
    // },
    // {
    //   id: 3,
    //   ime: "Dzeri",
    //   tip: "mis",
    //   god: 2,
    // },
  ]);

  //   let ispis = <h1>Lista nema elemenata</h1>;

  //   if (zivotinje.length !== 0) {
  //     ispis = zivotinje.map((zivotinja, idx) => {
  //       return (
  //         <li>
  //           {zivotinja.id} {zivotinja.ime} {zivotinja.tip} {zivotinja.god}
  //         </li>
  //       );
  //     });
  //   }

  return (
    <ul>
      {/* 1.nacin - koriscenje ternarnog operatora za uslovljavanje onoga sto se renderuje */}
      {/* uslov ? ako je uslov ispunjen : ako nije ispunjen uslov */}

      {/* {zivotinje.length === 0 ? (
        <h1>Lista nema elemenata</h1>
      ) : (
        zivotinje.map((zivotinja, idx) => {
          return (
            <li>
              {zivotinja.id} {zivotinja.ime} {zivotinja.tip} {zivotinja.god}
            </li>
          );
        })
      )} */}

      {/* 2.nacin - koriscenje AND '&&' operatora za uslovni rendering */}

      {/* {zivotinje.length === 0 && <h1>Lista nema elemenata</h1>} */}

      {/* 3.nacin - pripremanje promenljive za rendering u JS delu komponente */}

      {/* {ispis} */}

      {/* 4.nacin - izdvojiti ispis u posebnu komponentu - Prikaz */}

      {zivotinje.length > 0 ? (
        <Prikaz zivotinje={zivotinje} />
      ) : (
        <h1>Lista nema elemenata</h1>
      )}
    </ul>
  );
};

export default Lista;
