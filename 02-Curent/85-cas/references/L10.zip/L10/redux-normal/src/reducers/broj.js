const brojReducer = (state = 42, action) => {
  switch (action.type) {
    case "INCREMENT":
      return state + 1;
    case "DECREMENT":
      return state - 1;

    default:
      // ako nesto zeznete, da vam ne bi pukao program, neka samo vrati stanje
      return state;
  }
};

export default brojReducer;
