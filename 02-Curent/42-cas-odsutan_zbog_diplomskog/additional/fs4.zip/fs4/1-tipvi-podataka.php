<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHHP</title>
    <style>
        ol {
            border: 2px solid red;
            background: lightgray;

        }
    </style>
</head>
<body>
    <h1>Tipovi podataka</h1>
    <hr>
    <h2>Prosti ili skalarni tipovi podataka</h2>
    <ol>
        <li>integer</li>
        <li>float</li>
        <li>boolean</li>
        <li>string</li>
    </ol>
    <h2>Slozeni tipovi podataka</h2>
    <ol>
        <li>array</li>
        <li>object</li>
    </ol>
    <h2>Specijalni tipovi podataka</h2>
    <ol>
        <li>resource</li>
        <li>null</li>
    </ol>
</body>
</html>