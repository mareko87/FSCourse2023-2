// import Kontakti from "./Kontakti";
// import Chat from "./Chat";

const PodeljenaRavan = (props) => {
  return (
    <div>
      <h4>PodeljenaRavan</h4>

      {/* 1. nacin - bez kompozicije */}
      {/* <div className="container text-center">
        <div className="row">
          <div className="col">
            <Kontakti />
          </div>
          <div className="col">
            <Chat />
          </div>
        </div>
      </div> */}

      {/* sa kompozicijom */}
      <div className="container text-center">
        <div className="row">
          <div className="col">{props.levaKomponenta}</div>
          <div className="col">{props.desnaKomponenta}</div>
        </div>
      </div>
    </div>
  );
};

export default PodeljenaRavan;
