import React from "react";
import { useParams } from "react-router-dom";

const Details = ({ osobe }) => {
  const params = useParams();
  console.log(params.id);

  const osoba = osobe.filter((o) => {
    if (o.id === Number(params.id)) {
      return o;
    }
  })[0]; // je niz od jednog elementa

  return (
    <div>
      <h2>Details</h2>
      <h3>Id: {params.id}</h3>
      <h3>
        Ime i prezime: {osoba.prime} {osoba.godrod}
      </h3>
    </div>
  );
};

export default Details;
