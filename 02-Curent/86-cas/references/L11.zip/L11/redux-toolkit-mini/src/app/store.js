import { configureStore } from "@reduxjs/toolkit";

import brojSlice from "../components/Counter/brojSlice";

export const store = configureStore({
  reducer: {
    broj: brojSlice,
  },
});
