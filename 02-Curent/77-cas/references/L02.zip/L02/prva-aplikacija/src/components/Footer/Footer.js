// import React from 'react'

const Footer = () => {
  return <div>Ovo je footer aplikacije</div>;
};

export default Footer;
