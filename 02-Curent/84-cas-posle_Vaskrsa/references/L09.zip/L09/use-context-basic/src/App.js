import { createContext, useContext, useState } from "react";
import "./App.css";
import Komp2 from "./components/Komp2";

// ImePromenljiveContext - konvencija za nazivanje context-a
export const BrojContext = createContext();
// Vraca objekat sa 2 vrednosti {Provider, Consumer}
// Pristupamo BrojContext.Provider odnosno BrojContext.Consumer i koristimo ih kao custom made komponente odnosno kao html elemente (JSX) odnosno koristimo ih <BrojContext.Provider /> <BrojContext.Consumer  />

const OsobeContext = createContext();

const App = () => {
  // let broj = 42;

  const [osobe, setOsobe] = useState([
    {
      id: 1,
      ime: "Marko",
      prezime: "Markovic",
    },
    {
      id: 2,
      ime: "Filip",
      prezime: "Filipovic",
    },
    {
      id: 3,
      ime: "Bojan",
      prezime: "Bojanic",
    },
  ]);

  return (
    <div className="App">
      <h3>App komponenta</h3>

      <OsobeContext.Provider value={{ osobe, setOsobe }}>
        <BrojContext.Provider value={{ broj: 42 }}>
          <Komp1 />
          <Komp2 />
        </BrojContext.Provider>
      </OsobeContext.Provider>
    </div>
  );
};

export default App;

const Komp1 = () => {
  const { broj } = useContext(BrojContext);
  const { osobe, setOsobe } = useContext(OsobeContext);

  return (
    <>
      <h3>Komponenta 1</h3>

      <h4>Vrednost je {broj}</h4>

      {/* <BrojContext.Consumer>
        {({ broj }) => {
          return <h4>Vrednost je {broj}</h4>;
        }}
      </BrojContext.Consumer> */}

      <hr />

      <button
        onClick={() => {
          setOsobe((prev) => [
            ...prev,
            { id: 4, ime: "Milan", prezime: "Miric" },
          ]);
        }}
      >
        Dodaj osobu
      </button>

      <ul>
        {osobe.map((osoba) => {
          return (
            <li key={osoba.id}>
              Id: {osoba.id} Ime i prezime: {osoba.ime} {osoba.prezime}
            </li>
          );
        })}
      </ul>
    </>
  );
};
