const slika = document.querySelector('#slika');
const naziv = document.querySelector('#naziv');
const cena = document.querySelector('.price');
const opis = document.querySelector('#opis');
const kolicina = document.querySelector('#qty');
const kategorije = document.querySelector('.category');

const forma = document.querySelector('form');

let currentId = null;

let currentProduct = {};

window.addEventListener('load', () => {

    currentId = Number(sessionStorage.getItem("singleProduct"));

    fetch(`http://localhost:3000/${currentId}`)
        .then(proizvodRaw => proizvodRaw.json())

        /*
        .then(proizvodRaw => {
            return proizvodRaw.json()
        })
        */
        .then(proizvodJson => {
            // console.log(proizvodJson);
            currentProduct = proizvodJson[0];

            slika.innerHTML = `<img src="http://localhost:3000/${proizvodJson[0].img}" alt="">`;
            naziv.textContent = `${proizvodJson[0].name}`;
            cena.textContent = `${proizvodJson[0].price}`;
            opis.textContent = `${proizvodJson[0].desc}`;

            //Ispis kolicina
            kolicina.innerHTML = '';
            for (let i = 1; i <= proizvodJson[0].qty; i++) {
                kolicina.innerHTML += ` <option value="${i}">${i}</option>`
            };

            //Ispis kategorija
            let katTemp = currentProduct.category.split(',')
            // console.log(katTemp);

            kategorije.innerHTML = '';
            katTemp.forEach((element, idx) => {

                if (katTemp.length != idx + 1) {
                    kategorije.innerHTML += ` <a href="">${element.trim()}</a>,`
                } else {
                    kategorije.innerHTML += ` <a href="">${element.trim()}</a>`
                }

            });

        })
        .catch(err => console.log(err));
});

// let korpa = [];

forma.addEventListener('submit', (event) => {
    event.preventDefault();

    console.log(currentProduct)
    console.log(event.target.kolicina.value);

    currentProduct.qty = Number(event.target.kolicina.value)

    if (!sessionStorage.getItem('korpa')) {
        sessionStorage.setItem('korpa', '[]');
    }

    korpa = JSON.parse(sessionStorage.getItem('korpa'));

    // provera da li currentProduct postoji u korpi
    let tempRes = korpa.filter((item) => {
        if (item.id == currentId) {
            item.qty += Number(event.target.kolicina.value);
            return item;
        };
    })

    if (tempRes < 1) {
        korpa.push(currentProduct);
    }

    sessionStorage.setItem('korpa', JSON.stringify(korpa));
    //     // korpa.push(currentProduct);
    console.log(korpa);

    window.location = "products.html"

})