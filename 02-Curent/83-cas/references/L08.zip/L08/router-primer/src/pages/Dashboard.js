import React from "react";
import { useNavigate } from "react-router-dom";

const Dashboard = ({ osobe }) => {
  const navigate = useNavigate();

  return (
    <div>
      <h3>Dashboard</h3>
      <ul>
        {osobe.map((osoba) => {
          return (
            <li key={osoba.id}>
              {osoba.id} {osoba.prime} {osoba.godrod}
              <button
                onClick={() => {
                  navigate(`/details/${osoba.id}`);
                }}
                className="btn btn-success m-2"
              >
                Details
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Dashboard;
