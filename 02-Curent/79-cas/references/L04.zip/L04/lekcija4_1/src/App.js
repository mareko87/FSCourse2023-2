import { useState } from "react";
import "./App.css";
import Automobil from "./components/Automobil";

const App = () => {
  // document.getElementById("btn1").addEventListener("click", () => {
  //   dugmeClickHandler();
  // }); // NE KORISTI SE U REACT-U

  // let naziv = "Websitesworkshop";

  const [naziv, setNaziv] = useState("Websitesworkshop");

  const [osoba, setOsoba] = useState({
    ime: "",
    prezime: "",
    god: null,
  });

  const dugmeClickHandler = (event) => {
    // console.log("Kliknuli ste dugme");
    // console.log(event.target);

    // naziv = "Neki novi naziv"; //NE MOZE OVAKO DA SE MENJA

    setNaziv("Neki novi naziv");

    console.log(naziv);
  };

  const dodajOsobu = () => {
    setOsoba({ ime: "Marko", prezime: "Markovic", god: 30 });
  };

  const promeniOsobu = () => {
    // setOsoba({ ime: "Ivana", prezime: "Ivkovic", god: 23 });
    // setOsoba({ ime: "Ivana" }); //nije dobro

    setOsoba({ ime: "Ivana", prezime: osoba.prezime, god: osoba.god });
  };

  const obrisiOsobu = () => {
    setOsoba({ ime: "", prezime: "", god: null });
  };

  return (
    <div className="App">
      {/* <button onClick={dugmeClickHandler} style={{ margin: "5px" }}>
        Dugme
      </button> */}

      {/* <button id="btn1" style={{ margin: "5px" }}>
        Dugme
      </button> */}

      {/* <button
        onClick={() => {
          console.log("proba");
        }}
        style={{ margin: "5px" }}
      >
        Dugme
      </button> */}

      {/* <button
        onClick={(event) => {
          dugmeClickHandler(event);
        }}
        style={{ margin: "5px" }}
      >
        Dugme
      </button> */}

      {/* <button onClick={dugmeClickHandler} style={{ margin: "5px" }}>
        Dugme
      </button> */}

      <button onClick={dodajOsobu} style={{ margin: "5px" }}>
        Dodaj osobu
      </button>

      <button onClick={promeniOsobu} style={{ margin: "5px" }}>
        Promeni osobu
      </button>

      <button onClick={obrisiOsobu} style={{ margin: "5px" }}>
        Obrisi osobu
      </button>

      {/* <h2>Naziv: {naziv}</h2> */}

      <h3>Ime: {osoba.ime}</h3>
      <h3>Prezime: {osoba.prezime}</h3>
      <h3>Godine: {osoba.god}</h3>

      <Automobil />
      <Automobil />
      <Automobil />
    </div>
  );
};

export default App;
