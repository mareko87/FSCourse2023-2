/* eslint-disable array-callback-return */
import { useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";

import ProductsContext from "../context/ProductsContext";
import CartContext from "../context/CartContext";

const Single = () => {
  const params = useParams();
  const navigate = useNavigate();

  const { products, setProducts } = useContext(ProductsContext);
  const { cart, setCart } = useContext(CartContext);

  console.log(params.id); // kako smo definisali Route /single/:id (zato ide params.id)

  let product = products.filter((prod) => {
    if (prod.id === Number(params.id)) return prod; // vracamo taj jedan product
  })[0];

  console.log(product);

  // Kreiranje option menija u <select> elementu

  let option = [];

  // kretace od 1 do quantity-a
  for (let i = 1; i < product.qty; i++) {
    option.push(
      <option key={i} value={i}>
        {i}
      </option>
    );
  }

  // Kreiranje kategorija za prikaz

  let categElem = [];
  let catTemp = product.category.split(","); //ovo je niz

  catTemp.forEach((element, idx) => {
    // da li je duzina razlicita od idx+1? Ako jeste, pisemo jedno sa zarezom, a ako nije drugo bez zareza

    if (catTemp.length !== idx + 1) {
      categElem.push(
        <a key={idx} href="#">
          {element.trim()},
        </a>
      );
    } else {
      categElem.push(
        <a key={idx} href="#">
          {element.trim()}
        </a>
      );
    }
  });

  const addToCart = (event) => {
    event.preventDefault();

    cart.some((item) => {
      return item.id === params.id;
    })
      ? (cart.filter((item) => {
          if (item.id === params.id) {
            return item;
          }
        })[0].qty += Number(event.target.selectQty.value))
      : setCart((cart) => [
          ...cart,
          {
            id: params.id,
            name: product.name,
            price: product.price,
            img: product.img,
            qty: Number(event.target.selectQty.value),
          },
        ]);

    navigate("/products");
  };

  return (
    <section className="single container">
      <article className="row">
        <h2>Single product</h2>
      </article>
      <article className="row">
        <div>
          <img src={`${product.img}`} alt="" />
        </div>
        <div>
          <h3>{product.name}</h3>
          <div className="price">${product.price}</div>
          <p>{product.desc}</p>

          <form onSubmit={addToCart}>
            <label>Quantity</label>
            <select name="selectQty">
              {option}
              {/* <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option> */}
            </select>
            <button type="submit">Order now</button>
          </form>
          <hr />

          <p>
            Category: {categElem}
            {/* Category: <a href="">Men</a>, <a href="">Boots</a> */}
          </p>
          <hr />

          <span>Share: </span>
          <span>
            <a href="">
              <i className="fab fa-facebook-square"></i>
            </a>
          </span>
          <span>
            <a href="">
              <i className="fab fa-instagram"></i>
            </a>
          </span>
          <span>
            <a href="">
              <i className="fab fa-pinterest"></i>
            </a>
          </span>
          <span>
            <a href="">
              <i className="fab fa-twitter"></i>
            </a>
          </span>
        </div>
      </article>
    </section>
  );
};

export default Single;
