import { useContext } from "react";
import ProizvodiContext from "../context/ProizvodiContext";

const Proizvodi = () => {
  //   const [proizvodi, setProizvodi] = useState([
  //     {
  //       id: 1,
  //       naziv: "hleb",
  //       cena: 55,
  //     },
  //     {
  //       id: 2,
  //       naziv: "mleko",
  //       cena: 140,
  //     },
  //     {
  //       id: 3,
  //       naziv: "jogurt",
  //       cena: 230,
  //     },
  //   ]);

  const { proizvodi, setProizvodi } = useContext(ProizvodiContext);

  const formSubmit = (event) => {
    event.preventDefault();

    let noviProizvod = {
      id: proizvodi[proizvodi.length - 1].id + 1,
      naziv: event.target.naziv.value,
      cena: event.target.cena.value,
    };

    setProizvodi((prev) => [...prev, noviProizvod]);
  };

  return (
    <div>
      <h3>Proizvodi</h3>

      <form onSubmit={formSubmit}>
        <input type="text" placeholder="naziv" name="naziv" />
        <input type="number" placeholder="cena" name="cena" />
        <input type="submit" value="Dodaj" />
      </form>

      <ul>
        {proizvodi.map((proizvod) => {
          return (
            <li key={proizvod.id}>
              {/* {proizvod.id} {proizvod.naziv} {proizvod.cena} */}
              {proizvod.id} {proizvod.title} {proizvod.price}
            </li>
          );
        })}
      </ul>
      <hr />
    </div>
  );
};

export default Proizvodi;
