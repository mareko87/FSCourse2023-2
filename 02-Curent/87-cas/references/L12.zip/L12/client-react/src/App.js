// Components
import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import Topbar from "./components/Topbar";
// Pages
import Home from "./pages/Home";
import Products from "./pages/Products";
import Single from "./pages/Single";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Cart from "./pages/Cart";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";

import { Routes, Route } from "react-router-dom";

const App = () => {
  return (
    <div>
      <Topbar />
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        {/* sa :id moze da se prosledi promenljiva. kako smo definisali ovo :id tako ce se zvati promenljiva koja sadrzi params iz url-a npr {id: 0} */}
        <Route path="/single/:id" element={<Single />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/*" element={<NotFound />} />

        {/* POCETAK!!!!!!!!!! */}
        {/* <Home />
        <Products />
        <Single />
        <About />
        <Contact />
        <Cart />
        <Admin />
        <NotFound /> */}
      </Routes>

      <Footer />
    </div>
  );
};

export default App;
