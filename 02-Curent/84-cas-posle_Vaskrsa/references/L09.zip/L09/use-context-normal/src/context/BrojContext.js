import { createContext } from "react";

const BrojContext = createContext();

export const BrojProvider = ({ children }) => {
  return (
    <BrojContext.Provider value={{ broj: 42 }}>{children}</BrojContext.Provider>
  );
};

export default BrojContext;
