import React from "react";

const NotFound = () => {
  return <h3>Error 404 - Page Not Found</h3>;
};

export default NotFound;
