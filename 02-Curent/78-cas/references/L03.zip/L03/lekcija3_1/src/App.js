import "./App.css";
import Komp1 from "./components/Komp1/Komp1";
import Komp2 from "./components/Komp2/Komp2";
import Komp3 from "./components/Komp3/Komp3";

const App = () => {
  return (
    <div className="App">
      <h2>Kako se koristi CSS u React-u</h2>

      <Komp1 />
      <Komp2 />
      <Komp3 />
    </div>
  );
};

export default App;
