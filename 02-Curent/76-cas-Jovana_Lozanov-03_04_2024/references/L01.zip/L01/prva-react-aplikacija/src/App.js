import { useState } from "react";
import "./App.css";
import Nav from "./Nav";

const App = () => {
  // let broj = 24;
  let nekiTest = "Neki tekst 123";

  const [broj, setBroj] = useState(24);

  const povecaj = () => {
    console.log("proba 123");
    // broj = broj + 1;
    setBroj((broj) => broj + 1);
    console.log(broj);
  };

  return (
    <div htmlFor="" className="App">
      <Nav />
      <h1>Pozdrav iz react-a</h1>

      <h3>Broj je: {broj}</h3>

      <button className="btn btn-primary" onClick={povecaj}>
        Povecaj broj
      </button>
      <h3>{nekiTest}</h3>
    </div>
  );
};

export default App;
