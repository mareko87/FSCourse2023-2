import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: 0,
};

export const brojSlice = createSlice({
  name: "broj",
  initialState,
  reducers: {
    increment: (state) => {
      state.value += 1;
    },
    decrement: (state) => {
      state.value -= 1;
    },
  },
});

export const { increment, decrement } = brojSlice.actions;
export default brojSlice.reducer;
