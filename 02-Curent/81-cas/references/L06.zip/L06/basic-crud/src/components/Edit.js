import { useState, useEffect } from "react";

const Edit = ({ editMode, setEditMode, osobe, setOsobe }) => {
  const [ime, setIme] = useState("");
  const [prezime, setPrezime] = useState("");
  const [god, setGod] = useState("");

  // Hook za rad sa sporednim efektima
  useEffect(() => {
    setIme(editMode.ime);
    setPrezime(editMode.prezime);
    setGod(editMode.god);
  }, [editMode.id]);

  const exitEditMode = () => {
    setIme("");
    setPrezime("");
    setGod("");

    setEditMode({
      mode: false,
      id: "",
      ime: "",
      prezime: "",
      god: "",
    });
  };

  const snimi = () => {
    let tempOsobe = [...osobe];

    tempOsobe.forEach((osoba, idx) => {
      if (editMode.id === osoba.id) {
        tempOsobe[idx].ime = ime;
        tempOsobe[idx].prezime = prezime;
        tempOsobe[idx].god = god;
      }
    });

    setOsobe([...tempOsobe]);

    exitEditMode();
  };

  return (
    <div style={{ marginBottom: "20px" }}>
      <h2>Edit</h2>
      <div>
        <label>Ime</label>
        <input
          type="text"
          value={ime}
          name="ime"
          onChange={(event) => setIme(event.target.value)}
        />
        <label>Prezime</label>
        <input
          type="text"
          value={prezime}
          onChange={(event) => setPrezime(event.target.value)}
        />
        <label>Godine</label>
        <input
          type="text"
          value={god}
          onChange={(event) => setGod(event.target.value)}
        />
        <button style={{ marginLeft: "5px" }} onClick={snimi}>
          Snimi
        </button>
        <button style={{ marginLeft: "5px" }} onClick={exitEditMode}>
          X
        </button>
      </div>
    </div>
  );
};

export default Edit;
