import { useState, useEffect, useRef } from "react";
import "./App.css";

const App = () => {
  const [natpis, setNatpis] = useState("");
  // const [brojac, setBrojac] = useState(0);

  const [ime, setIme] = useState("");
  const [prezime, setPrezime] = useState("");

  const frmInputIme = useRef("");
  const frmInputPrezime = useRef("");
  const frm = useRef("");

  const renderBrojac = useRef(0);

  // console.log(renderBrojac);

  useEffect(() => {
    // setBrojac((prev) => prev + 1);
    // renderBrojac = renderBrojac + 1;
    renderBrojac.current += 1;
  });

  const submitBezForme = () => {
    console.log(frmInputIme.current);
    console.log(frmInputIme.current.value);

    // setIme("");
    // setPrezime("");

    frmInputIme.current.value = "";
    frmInputPrezime.current.value = "";

    frmInputIme.current.focus();
  };

  const formSubmit = (event) => {
    event.preventDefault();
    console.log(frm.current);
    console.log(frm.current.nIme);
    console.log(frm.current.nIme.value);

    frmInputIme.current.value = "";
    frmInputPrezime.current.value = "";

    frmInputIme.current.focus();
  };

  return (
    <div className="App">
      <input
        type="text"
        value={natpis}
        onChange={(event) => setNatpis(event.target.value)}
      />

      <h3>Natpis je: {natpis}</h3>

      <h3>Stranica je renderovana: {renderBrojac.current} puta.</h3>

      <hr />

      {/* <input
        ref={frmInputIme}
        type="text"
        placeholder="ime"
        value={ime}
        onChange={(event) => setIme(event.target.value)}
      />
      <input
        ref={frmInputPrezime}
        type="text"
        placeholder="prezime"
        value={prezime}
        onChange={(event) => setPrezime(event.target.value)}
      />
      <button onClick={submitBezForme}>Submit bez forme</button> */}

      <form ref={frm} onSubmit={formSubmit}>
        <input
          ref={frmInputIme}
          type="text"
          placeholder="ime"
          name="nIme"
          value={ime}
          onChange={(event) => setIme(event.target.value)}
        />
        <input
          ref={frmInputPrezime}
          type="text"
          placeholder="prezime"
          value={prezime}
          onChange={(event) => setPrezime(event.target.value)}
        />
        <input type="submit" value="Submit" />
      </form>
    </div>
  );
};

export default App;
