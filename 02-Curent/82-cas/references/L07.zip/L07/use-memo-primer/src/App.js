import { useState, useRef, useMemo } from "react";
import "./App.css";

const App = () => {
  const [broj, setBroj] = useState(0);
  const [brojac, setBrojac] = useState(0);

  const inputField = useRef("");

  const faktorijel = (n) => {
    console.log(`Pozvan je faktorijel od ${n}`);

    // if (n <= 1) {
    //   return 1;
    // }

    // return faktorijel(n - 1) * n;

    return n <= 1 ? 1 : faktorijel(n - 1) * n; // rekurzija - kada funkcija poziva samu sebe
  };

  const racunaj = () => {
    setBroj(Number(inputField.current.value));
  };

  // const rez =  faktorijel(broj);

  const rez = useMemo(() => {
    return faktorijel(broj);
  }, [broj]);

  return (
    <div className="App">
      <h3>Primer faktorijel</h3>
      <input type="text" ref={inputField} />
      <button onClick={racunaj}>Racunaj</button>
      <button onClick={() => setBrojac((prev) => prev + 1)}>Re-render</button>

      <h3>Rezultat je: {rez}</h3>
    </div>
  );
};

export default App;

// Faktorijel
// 0! = 1
// 1! = 1
// 3! = 3 * 2 * 1 = 6
// 4! = 4 * 3 * 2 * 1 = 24
// 5! = 5 * 4 * 3 * 2 * 1 = 120
