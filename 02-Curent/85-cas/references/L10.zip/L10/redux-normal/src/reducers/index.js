import { combineReducers } from "redux";
import brojReducer from "./broj";
import itemsReducer from "./items";

const allReducers = combineReducers({
  broj: brojReducer,
  items: itemsReducer,
});

export default allReducers;
