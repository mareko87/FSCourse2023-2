const productTable = document.querySelector('#productTable');

const naslovForme = document.querySelector('#naslovForme');

const frmName = document.querySelector('#frmName');
const frmPrice = document.querySelector('#frmPrice');
const frmDesc = document.querySelector('#frmDesc');
const frmCategory = document.querySelector('#frmCategory');
const frmQty = document.querySelector('#frmQty');
const lblImg = document.querySelector('#lblImg');
const frmImg = document.querySelector('#frmImg');

const addButton = document.querySelector('#addButton');
const editBtn = document.querySelector('#editBtn');
const cancelBtn = document.querySelector('#cancelBtn');


let editId = null;

window.addEventListener('load', () => {
    ispisProizvoda();
})

const ispisProizvoda = () => {
    fetch('http://localhost:3000/')
        .then(res => res.json())
        .then(resJson => {

            productTable.innerHTML = '';
            resJson.forEach(proizvod => {
                productTable.innerHTML += `
                <tr>
                    <th scope="row">${proizvod.id}</th>
                    <td> <img src="http://localhost:3000/${proizvod.img}" alt="" height="30px"></td>
                    <td>${proizvod.name}</td>
                    <td>${proizvod.qty}</td>
                    <td>$${proizvod.price}</td>
                    <td><button class="btn btn-info" onclick="viewProduct(${proizvod.id})">View</button></td>
                    <td><button class="btn btn-warning" onclick="editProduct(${proizvod.id})" data-bs-toggle="modal" data-bs-target="#dodaj">Edit</button></td>
                    <td><button class="btn btn-danger" onclick="removeProduct(${proizvod.id})">Delete</button></td>
                </tr>
                `

            });
        })
        .catch(err => console.log(err));
};

const viewProduct = (id) => {
    sessionStorage.setItem("singleProduct", id)
    window.location = 'single.html'
}

const editProduct = (id) => {

    editId = id;

    addButton.hidden = true;

    lblImg.hidden = true;
    frmImg.hidden = true;

    editBtn.hidden = false;
    cancelBtn.hidden = false;

    naslovForme.textContent = 'Edit product'

    fetch(`http://localhost:3000/${id}`)
        .then(proizvodRaw => proizvodRaw.json())
        .then(proizvodJson => {
            frmName.value = `${proizvodJson[0].name}`;
            frmPrice.value = `${proizvodJson[0].price}`;
            frmDesc.value = `${proizvodJson[0].desc}`;
            frmCategory.value = `${proizvodJson[0].category}`;
            frmQty.value = `${proizvodJson[0].qty}`;
        })
        .catch(err => console.log(err));

}

editBtn.addEventListener('click', () => {
    const data = {
        name: frmName.value,
        price: frmPrice.value,
        desc: frmDesc.value,
        category: frmCategory.value,
        qty: frmQty.value
    }

    fetch(`http://localhost:3000/edit/${editId}`, {
        method: 'PUT',
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data)
    })
        .then(proizvodRaw => proizvodRaw.json())
        .then(proizvodJson => {
            console.log(proizvodJson);

            editId = null

            addButton.hidden = false;

            lblImg.hidden = false;
            frmImg.hidden = false;

            editBtn.hidden = true;
            cancelBtn.hidden = true;

            naslovForme.textContent = 'New product'

            frmName.value = '';
            frmPrice.value = '';
            frmDesc.value = '';
            frmCategory.value = '';
            frmQty.value = '';

            ispisProizvoda();

        })
        .catch(err => console.log(err));
})


cancelBtn.addEventListener('click', () => {
    editId = null

    addButton.hidden = false;

    lblImg.hidden = false;
    frmImg.hidden = false;

    editBtn.hidden = true;
    cancelBtn.hidden = true;

    naslovForme.textContent = 'New product'

    frmName.value = '';
    frmPrice.value = '';
    frmDesc.value = '';
    frmCategory.value = '';
    frmQty.value = '';
})

const removeProduct = (id) => {
    fetch(`http://localhost:3000/delete/${id}`, {
        method: 'DELETE'
    })
        .then(res => res.json())
        .then(resJson => {
            console.log(resJson);
        })
        .catch(err => console.log(err));
}
