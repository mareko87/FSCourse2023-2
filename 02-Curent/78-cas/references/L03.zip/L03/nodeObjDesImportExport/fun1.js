exports.sabiraj = (a, b) => {
  return a + b;
};

exports.osoba = {
  ime: "Pera",
  prezime: "Perovic",
  godine: 44,
};
