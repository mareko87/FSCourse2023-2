import React from "react";

const Kontakti = ({ naziv }) => {
  return (
    <div>
      <h4>Kontakti</h4>
      {naziv}
    </div>
  );
};

export default Kontakti;
