export const stiloviH1 = { color: "aquamarine", backgroundColor: "orange" };
export const stiloviH2 = { color: "yellow", backgroundColor: "black" };
