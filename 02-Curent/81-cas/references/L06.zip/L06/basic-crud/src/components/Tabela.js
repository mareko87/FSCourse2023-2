import React from "react";
import "./Tabela.css";

const Tabela = ({ osobe, setOsobe, setEditMode }) => {
  const obrisi = (idx) => {
    let tempOsobe = [...osobe];
    tempOsobe.splice(idx, 1);
    setOsobe(tempOsobe);
  };

  const editMode = (idx) => {
    setEditMode({
      mode: true,
      id: osobe[idx].id,
      ime: osobe[idx].ime,
      prezime: osobe[idx].prezime,
      god: osobe[idx].god,
    });
  };

  return (
    <div className="container">
      <table>
        <thead>
          <tr>
            <th>Id</th>
            <th>Ime</th>
            <th>Prezime</th>
            <th>Godine</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {osobe.map((osoba, idx) => {
            return (
              <tr key={osoba.id}>
                <td>{osoba.id}</td>
                <td>{osoba.ime}</td>
                <td>{osoba.prezime}</td>
                <td>{osoba.god}</td>
                <td>
                  <button onClick={() => editMode(idx)}>Edit</button>
                </td>
                <td>
                  <button onClick={() => obrisi(idx)}>X</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default Tabela;
