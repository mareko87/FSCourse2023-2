const imeFunkcije = () => {
  console.log("proba da vidimo kako radi");
};
