import stilovi from "./Detalj.module.css";

const Detalj = ({ automobil, children }) => {
  return (
    <div className={stilovi.detalj}>
      <label>
        {children} id: {automobil.id} marka: {automobil.marka} godine:{" "}
        {automobil.god}
      </label>
      <button className={stilovi.dugme}>Dugme</button>
    </div>
  );
};

export default Detalj;
