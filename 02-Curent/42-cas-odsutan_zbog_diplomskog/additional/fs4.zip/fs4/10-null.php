<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <h1>NULL</h1>
    <?php 
    $test = "";
    echo $test;
    echo "<br>";
    $vrednost = null;
    var_dump($vrednost);
    ?>
</body>
</html>