import React from "react";

const NotFound = () => {
  return <h2 className="text-center">Error 404 - Page Not Found</h2>;
};

export default NotFound;
