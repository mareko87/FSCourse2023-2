import { useState } from "react";
import "./App.css";
import Tabela from "./components/Tabela";
import AddNew from "./components/AddNew";
import { v4 as uuidv4 } from "uuid";
import Edit from "./components/Edit";

const App = () => {
  const [editMode, setEditMode] = useState({
    mode: false,
    id: "",
    ime: "",
    prezime: "",
    god: "",
  });

  const [osobe, setOsobe] = useState([
    {
      id: uuidv4(),
      ime: "Petar",
      prezime: "Petrovic",
      god: 42,
    },
    {
      id: uuidv4(),
      ime: "Mira",
      prezime: "Miric",
      god: 32,
    },
    {
      id: uuidv4(),
      ime: "Visnja",
      prezime: "Visnjic",
      god: 21,
    },
    {
      id: uuidv4(),
      ime: "Marko",
      prezime: "Markovic",
      god: 18,
    },
  ]);

  return (
    <div className="App">
      {!editMode.mode ? (
        <AddNew osobe={osobe} setOsobe={setOsobe} />
      ) : (
        <Edit
          editMode={editMode}
          setEditMode={setEditMode}
          osobe={osobe}
          setOsobe={setOsobe}
        />
      )}

      <Tabela osobe={osobe} setOsobe={setOsobe} setEditMode={setEditMode} />
    </div>
  );
};

export default App;
