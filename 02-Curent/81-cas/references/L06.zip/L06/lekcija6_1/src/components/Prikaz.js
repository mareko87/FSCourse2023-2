import React from "react";

const Prikaz = ({ zivotinje }) => {
  return (
    <div>
      {zivotinje.map((zivotinja, idx) => {
        return (
          <li>
            {zivotinja.id} {zivotinja.ime} {zivotinja.tip} {zivotinja.god}
          </li>
        );
      })}
    </div>
  );
};

export default Prikaz;
