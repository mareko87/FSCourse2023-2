import React from "react";

const Topbar = () => {
  return (
    <section className="topbar">
      <h1>
        <a href="index.html" className="logo">
          <i className="fas fa-hiking"></i>Hiking shop
        </a>
      </h1>
    </section>
  );
};

export default Topbar;
