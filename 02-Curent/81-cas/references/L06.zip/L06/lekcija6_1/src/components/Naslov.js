import React from "react";

const Naslov = () => {
  return (
    <>
      <h3>Ovo je neki naslov ili Navbar</h3>
      <hr />
    </>
  );
};

export default Naslov;
