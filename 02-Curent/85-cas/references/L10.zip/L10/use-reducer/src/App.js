/* eslint-disable default-case */
import { useState, useReducer } from "react";
import "./App.css";

const reducer = (state, action) => {
  switch (action.type) {
    case "increment":
      return { ...state, count: state.count + 1 };
    case "decrement":
      return { ...state, count: state.count - 1 };
    case "newUserInput":
      return { ...state, userInput: action.payload };
    case "changeTheme":
      return { ...state, theme: !state.theme };
  }
};

const ACTION = {
  INCREMENT: "increment",
  DECREMENT: "decrement",
  NEW_USER_INPUT: "newUserInput",
  CHANGE_THEME: "changeTheme",
};

const App = () => {
  const [state, dispatch] = useReducer(reducer, {
    count: 0,
    userInput: "",
    theme: true,
  });

  // const [count, setCount] = useState(0);
  // const [userInput, setUserInput] = useState("");
  // const [theme, setTheme] = useState("white");

  // const promeniTemu = () => {
  //   theme === "white" ? setTheme("black") : setTheme("white");
  // };

  return (
    <div className={`App ${state.theme ? "white" : "black"}`}>
      <h4>
        <button
          style={{ margin: "3px" }}
          onClick={() => dispatch({ type: ACTION.DECREMENT })}
        >
          -
        </button>
        {state.count}
        <button
          style={{ margin: "3px" }}
          onClick={() => dispatch({ type: ACTION.INCREMENT })}
        >
          +
        </button>
      </h4>

      <input
        type="text"
        value={state.userInput}
        onChange={(event) =>
          dispatch({ type: ACTION.NEW_USER_INPUT, payload: event.target.value })
        }
      />
      {state.userInput}

      <br />

      <button
        style={{ margin: "3px" }}
        onClick={() => dispatch({ type: ACTION.CHANGE_THEME })}
      >
        Tema
      </button>

      {/* <h4>
        <button
          style={{ margin: "3px" }}
          onClick={() => setCount((broj) => broj - 1)}
        >
          -
        </button>
        {count}
        <button
          style={{ margin: "3px" }}
          onClick={() => setCount((broj) => broj + 1)}
        >
          +
        </button>
      </h4>

      <input
        type="text"
        value={userInput}
        onChange={(event) => setUserInput(event.target.value)}
      />
      {userInput}

      <br />

      <button style={{ margin: "3px" }} onClick={promeniTemu}>
        Tema
      </button> */}
    </div>
  );
};

export default App;

// reducer - nacin kako akcija utice na stanje

// action - opisni nacin prikaza mogucih akcija nad stanjem

// state - {objekat sa vise stanja} - {ime: '', prezime: '', god: 45}

// dispatch - dispatch-uje akciju
