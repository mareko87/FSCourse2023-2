/* eslint-disable default-case */
const pocetniUslovi = [
  {
    id: 1,
    naziv: "hleb",
    cena: 100,
  },
  {
    id: 2,
    naziv: "mleko",
    cena: 150,
  },
  {
    id: 3,
    naziv: "jogurt",
    cena: 200,
  },
];

const itemsReducer = (state = pocetniUslovi, action) => {
  switch (action.type) {
    case "ADD":
      // action.payload -> dodali ono sto cemo da posaljemo iz ona dva input polja
      return [...state, action.payload];

    default:
      // ako nesto zeznete, da vam ne bi pukao program, neka samo vrati stanje
      return state;
  }
};

export default itemsReducer;
