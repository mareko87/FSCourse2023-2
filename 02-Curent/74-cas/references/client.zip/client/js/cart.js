const cartTable = document.querySelector('#cartTable');

window.addEventListener('load', () => {
    if (sessionStorage.getItem('korpa')) {
        korpa = JSON.parse(sessionStorage.getItem('korpa'));
    }
    ispisKorpe();
})

const ispisKorpe = () => {
    cartTable.innerHTML = '';

    korpa.forEach((stavka, idx) => {
        cartTable.innerHTML += `
        <tr>
            <th scope="row">${idx + 1}</th>
            <td><img src="http://localhost:3000/${stavka.img}" alt="" height="30px"></td>
            <td>${stavka.name}</td>
            <td>$${stavka.price}</td>
            <td>${stavka.qty}</td>
            <td>$${stavka.price * stavka.qty}</td>
            <td><button class="btn btn-danger" onclick="removeItem(${stavka.idx})">X</button></td>
        </tr>
        `
    })

    let total = korpa.reduce((acc, currVal) => {
        return acc + currVal.qty * currVal.price
    }, 0);

    cartTable.innerHTML += `
    <tr>
        <th scope="row"></th>
        <td></td>
        <td></td>
        <td></td>
        <td>Total:</td>
        <td>$${total}</td>
        <td></td>
    </tr>
    `
}

const removeItem = (idx) => {

    korpa = JSON.parse(sessionStorage.getItem('korpa'));
    korpa.splice(idx, 1);
    sessionStorage.setItem('korpa', JSON.stringify(korpa));

    document.querySelector('#brStavki').innerHTML = `(${korpa.length})`
    ispisKorpe();
}


const clearCart = () => {
    korpa = JSON.parse(sessionStorage.getItem('korpa'));
    korpa = [];
    sessionStorage.setItem('korpa', JSON.stringify(korpa));

    cartTable.innerHTML = ''
}