import React from "react";

const MapaAbout = () => {
  return <div>MapaAbout</div>;
};

export default MapaAbout;
