import stilovi from "./Komp3.module.css";

const Komp3 = () => {
  return (
    <div>
      <h1 className={stilovi.h1Stil}>Pozdrav iz komponente 3</h1>
      <h2 className={stilovi.h2Stil}>Neki h2 u komponenti 3</h2>
    </div>
  );
};

export default Komp3;
