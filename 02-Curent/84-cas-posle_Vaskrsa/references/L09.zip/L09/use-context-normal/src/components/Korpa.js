import React from "react";

const Korpa = () => {
  return (
    <div>
      <h3>Korpa</h3>
    </div>
  );
};

export default Korpa;
