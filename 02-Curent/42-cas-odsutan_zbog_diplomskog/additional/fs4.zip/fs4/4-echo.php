<?php 
echo("<html>");
echo("<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.'>
    <title>php</title>
    </head>");
echo("<body>");
echo("<h1>Echo funkcija</h1>");
echo("<hr>");
echo("</body>");
echo("</html>");
?>