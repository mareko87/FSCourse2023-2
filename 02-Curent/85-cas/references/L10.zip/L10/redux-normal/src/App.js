import "./App.css";
import Navbar from "./components/Navbar";
import Proizvodi from "./components/Proizvodi";

const App = () => {
  return (
    <div className="App">
      <Navbar />

      <Proizvodi />
    </div>
  );
};

export default App;
