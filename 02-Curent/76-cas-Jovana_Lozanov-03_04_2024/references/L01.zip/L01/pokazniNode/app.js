// console.log("proba 123");

const express = require("express");
const app = express();

app.get("/", (req, res) => {
  res.send("<h1>Pozdrav sa bekenda iz node.js-a sa porta 3000</h1>!!!!!");
});

app.listen(3000, () => {
  console.log("...Server is listening on port 3000...");
});
