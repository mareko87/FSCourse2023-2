/* eslint-disable default-case */
import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { legacy_createStore as createStore } from "redux";

// action - opisuje ono sto zelimo da radimo sa stanjem
const increment = () => {
  return {
    type: "INCREMENT",
  };
};

const decrement = () => {
  return {
    type: "DECREMENT",
  };
};

// reducer - opisuje kako neka akcija utice na nase stanje i kako ga transformise, kako ce stanje izgledati posle zeljene akcije
const counter = (state = 0, action) => {
  switch (action.type) {
    case "INCREMENT":
      return state + 1;
    case "DECREMENT":
      return state - 1;
  }
};

// store - stanje na nivou projekta (globalno stanje)
const store = createStore(counter);

store.subscribe(() => console.log(store.getState()));

// dispatch - povezuje akciju i reducer - poziva odredjenu akciju - dispecuj mi ovu akciju sa ovim reducerom

store.dispatch(increment());
store.dispatch(increment());
store.dispatch(increment());
store.dispatch(decrement());

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
