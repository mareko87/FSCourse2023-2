import Detalj from "./Detalj";
import stilovi from "./Kartica.module.css";

const Kartica = ({ automobili }) => {
  //   console.log(props);
  console.log(automobili);
  return (
    <div className={stilovi.container}>
      {/* Rucni nacin */}
      {/* <h3>
        {automobili[0].id} {automobili[0].marka} {automobili[0].tip}{" "}
        {automobili[0].god}
      </h3>
      <h3>
        {automobili[1].id} {automobili[1].marka} {automobili[1].tip}{" "}
        {automobili[1].god}
      </h3>
      <h3>
        {automobili[2].id} {automobili[2].marka} {automobili[2].tip}{" "}
        {automobili[2].god}
      </h3> */}

      {/* <Detalj
        id={automobili[0].id}
        marka={automobili[0].marka}
        god={automobili[0].god}
      /> */}

      {/* <Detalj
        id={automobili[0].id}
        marka={automobili[0].marka}
        god={automobili[0].god}
      />
      <Detalj
        id={automobili[1].id}
        marka={automobili[1].marka}
        god={automobili[1].god}
      />
      <Detalj
        id={automobili[2].id}
        marka={automobili[2].marka}
        god={automobili[2].god}
      /> */}

      {/* upoznavanje sa children  */}
      {/* <Detalj
        id={automobili[0].id}
        marka={automobili[0].marka}
        god={automobili[0].god}
      >
        Proba 123
      </Detalj> */}

      {/* <Detalj
        id={automobili[0].id}
        marka={automobili[0].marka}
        god={automobili[0].god}
      >
        {automobili[0].tip}
      </Detalj>
      <Detalj
        id={automobili[1].id}
        marka={automobili[1].marka}
        god={automobili[1].god}
      >
        {automobili[1].tip}
      </Detalj>
      <Detalj
        id={automobili[2].id}
        marka={automobili[2].marka}
        god={automobili[2].god}
      >
        {automobili[2].tip}
      </Detalj> */}

      {/* {automobili.map((automobil, idx) => {
        return (
          <Detalj key={idx} id={automobil.id} marka={automobil.marka} god={automobil.god}>
            {automobil.tip}
          </Detalj>
        );
      })} */}

      {automobili.map((automobil, idx) => {
        return (
          <Detalj key={automobil.id} automobil={automobil}>
            {automobil.tip}
          </Detalj>
        );
      })}
    </div>
  );
};

export default Kartica;
