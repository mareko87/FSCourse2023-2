export const oduzimaj = (a, b) => {
  return a - b;
};

export const auto = {
  proizvodjac: "kia",
  tip: "ceed",
  god: 2018,
};

// export default oduzimaj;
// export { oduzimaj, auto };
