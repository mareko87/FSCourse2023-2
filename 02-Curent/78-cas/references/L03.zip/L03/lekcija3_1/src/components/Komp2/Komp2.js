import { stiloviH1, stiloviH2 } from "./Komp2.style";
const Komp2 = () => {
  return (
    <div>
      <h1 style={stiloviH1}>Pozdrav iz komponente 2</h1>
      <h2 style={stiloviH2}>Neki h2 u KOmponenti 2</h2>
    </div>
  );
};

export default Komp2;
