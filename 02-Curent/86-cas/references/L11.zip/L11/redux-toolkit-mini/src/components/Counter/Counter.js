import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement } from "./brojSlice";

const Counter = () => {
  const broj = useSelector((state) => state.broj.value); // sa state pristupam objektu koji sadrzi broj iz store.js, a ja zelim da pristupim tom broj, pa njegovoj vrednosti (value)

  const dispatch = useDispatch();

  return (
    <div>
      <button onClick={() => dispatch(decrement())}>-</button>
      {broj}
      <button onClick={() => dispatch(increment())}>+</button>
    </div>
  );
};

export default Counter;
