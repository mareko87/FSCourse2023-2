import React from "react";

const Footer = () => {
  return (
    <div className="m-0" style={{ backgroundColor: "lightgray" }}>
      <p>Copyright &copy; {new Date().getFullYear()}</p>
      <a href="/">Kompleksna aplikacija</a>
    </div>
  );
};

export default Footer;
